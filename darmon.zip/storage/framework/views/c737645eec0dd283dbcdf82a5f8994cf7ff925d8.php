<?php $__env->startSection('section'); ?>

    <div class="dash-content">
        <div class="overview">
            <div class="title">
                <i class="fas fa-notes-medical"></i>
                <span class="text" id="glavni">Imtixon natijalari</span>
            </div>
            <div class="fan_cards" id="fan-cards">
                <?php if(count($subjects) > 0): ?>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="fan_card">
                            
                            <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
                            <lottie-player src="https://assets10.lottiefiles.com/private_files/lf30_46kycmnm.json" background="transparent" speed="1" style="width: 300px; height: 300px;" loop="" autoplay=""></lottie-player>
                            <h2 class="fan_title"><?php echo e($subject->name); ?></h2>
                            <a href="<?php echo e(route('subject_results', ['id' => $subject->id])); ?>"><button type="submit" class="fan_btn">Ko'rish</button></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        <?php if(!empty($delete)): ?>
        <?php if($delete == 'true'): ?>
        alert('Fan o\'chirildi')
        <?php else: ?>
        alert('Fan o\'chirilmadi')
        <?php endif; ?>
        <?php endif; ?>
        function formOpen(){
            document.getElementById('fan-cards').style.display = 'none';
            document.getElementById('bu').style.display = 'none';
            document.getElementById('form-style').style.display = 'block';
            document.getElementById('glavni').textContent = "Yangi fan qo'shish";
        }
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\darmon\resources\views/admin/results.blade.php ENDPATH**/ ?>