<?php $__env->startSection('section'); ?>

        <div class="dash-content">
            <div class="overview">
                <div class="title">
                    <i class="fas fa-notes-medical"></i>
                    <span class="text" id="glavni">Vacant uchun imtihon fanlar</span>
                </div>

                <div class="form-style-2" id="form-style" style="display: none">
                    <div class="info">
                        <form action="<?php echo e(route('vacant_sb_reg')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="field1"><span class="required">Fan nomi <span class="required ">*</span></span>
                                <input type="text" class="input-field" name="name">
                            </label>
                            <label for="field2"><span class="required">Test nechta chiqsin <span class="required ">*</span></span>
                                <input type="number" class="input-field" name="count">
                            </label>
                            <label for="field1"><span class="required">Test vaqti qancha (minut) <span class="required ">*</span></span>
                                <input type="number" class="input-field" name="time">
                            </label>
                            <br><br>
                            <label><button class="btn" type="submit">Saqlash</button></label>
                        </form>
                    </div>
                </div>
                <div class="fan_cards" id="fan-cards">
                    <?php if(count($subjects) > 0): ?>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="fan_card">
                                
                                <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
                                <lottie-player src="https://assets10.lottiefiles.com/private_files/lf30_46kycmnm.json" background="transparent" speed="1" style="margin: auto; width: 300px; height: 300px;" loop="" autoplay=""></lottie-player>
                                <h2 class="fan_title"><?php echo e($subject->name); ?></h2>
                                <a href="<?php echo e(route('vacant_subject', ['id' => $subject->id])); ?>"><button type="submit" class="fan_btn">Kirish</button></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        <?php if(!empty($delete)): ?>
        <?php if($delete == 'true'): ?>
        alert('Fan o\'chirildi')
        <?php else: ?>
        alert('Fan o\'chirilmadi')
        <?php endif; ?>
        <?php endif; ?>
        function formOpen(){
            document.getElementById('fan-cards').style.display = 'none';
            document.getElementById('bu').style.display = 'none';
            document.getElementById('form-style').style.display = 'block';
            document.getElementById('glavni').textContent = "Yangi fan qo'shish";
        }
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\darmon\resources\views/admin/vacant_subjects.blade.php ENDPATH**/ ?>