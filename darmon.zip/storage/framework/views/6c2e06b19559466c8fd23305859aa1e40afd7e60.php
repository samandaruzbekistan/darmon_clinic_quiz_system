<?php $__env->startSection('section'); ?>

        <br>
        <?php if(count($vacants) > 0): ?>
            <div class="dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="fas fa-user-md"></i>
                        <span class="text" id="glavni">Vakantlar ro'yhati</span>
                    </div>
                    <button id="bu" class="btn" onclick="formOpen()">Yangi vacant qo'shish <i class="fas fa-rectangle-history-circle-plus"></i></button>
                    <form action="<?php echo e(route('new_vacant_reg')); ?>" class="form-style-2" method="post" id="form-style" style="display: none">
                        <?php echo csrf_field(); ?>
                        <label for="field1"><span class="required">F.I.Sh <span class="required ">*</span></span>
                            <input type="text" class="input-field" name="name">
                        </label>
                        <br><br>
                        <label><button class="btn" type="submit">Saqlash</button></label>
                    </form>
                    <br>
                    <br>
                    <div class="card shadow">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>F.I.Sh</th>
                                        <th>Natija</th>
                                        <th>Delete</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $vacants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($id+1); ?></td>
                                            <td><?php echo e($item->fullname); ?></td>
                                            <td><?php echo e($item->results); ?>%</td>
                                            <td style="text-align: center; vertical-align: top">
                                                <form action="<?php echo e(route('delete_nurse')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="nurse_id" value="<?php echo e($item->id); ?>">
                                                    <button type="submit" class="btn" style="background-color: red"><i class="fa fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="fas fa-user-md"></i>
                        <span class="text" id="glavni">Vacantlar hali kiritilmagan!</span>
                    </div>
                    <button id="bu" class="btn" onclick="formOpen()">Yangi hamshira qo'shish <i class="fas fa-rectangle-history-circle-plus"></i></button>
                    <form action="<?php echo e(route('new_vacant_reg')); ?>" class="form-style-2" method="post" id="form-style" style="display: none">
                        <?php echo csrf_field(); ?>
                        <label for="field1"><span class="required">F.I.Sh <span class="required ">*</span></span>
                            <input type="text" class="input-field" name="name">
                        </label>
                        <label for="field1"><span class="required">Telefon (971234567) <span class="required ">*</span></span>
                            <input type="number" class="input-field" name="phone" minlength="9" maxlength="9">
                        </label>
                        <br><br>
                        <label><button class="btn" type="submit">Saqlash</button></label>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script type="application/javascript">
        function formOpen(){
            document.getElementById('form-style').style.display = 'block';
            document.getElementById('bu').style.display = 'none';
        }

        function openEdit(){
            document.getElementById('form-edit').style.display = 'block';
        }

        function trash(){

            if (confirm("Fan bilan qo'shilib barcha savollari ham o'chiriladi") === true) {
                document.getElementById('submit-btn').click();
            }
        }

    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\darmon\resources\views/admin/vacants.blade.php ENDPATH**/ ?>