<?php $__env->startSection('section'); ?>

        <div class="dash-content">
            <div class="overview">
                <div class="title">
                    <i class="fas fa-notes-medical"></i>
                    <span class="text"><?php echo e($subject->name); ?></span>
                </div>
                <div class="fan_cards" id="fan-cards">
                    <div class="detail_card border-left-primary">
                        <div class="card-body">
                            <div class="align-items-center no-gutters">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                        Testlar soni</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($subject->count_quiz); ?> ta</div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button class="detail_card border-left-primary" onclick="formOpen()">
                        <div class="card-body">
                            <div class="align-items-center">
                                <div class="col">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1" style="text-decoration: none;">
                                        Yangi savol
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><i class="fas fa-plus" style="color: #4E73DF"></i></div>
                                </div>
                            </div>
                        </div>
                    </button>
                    <button class="detail_card border-left-success" onclick="openEdit()">
                        <div class="card-body">
                            <div class="align-items-center">
                                <div class="col">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1" style="text-decoration: none;">
                                        Taxrirlash
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><i class="fas fa-edit" style="color: #15a200"></i></div>
                                </div>
                            </div>
                        </div>
                    </button>
                </div>
                <div class="form-style-2" id="form-edit" style="display: none">
                    <div class="info">
                        <form action="<?php echo e(route('vacant_subject_update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">
                            <label for="field1"><span class="required">Fan nomi <span class="required ">*</span></span>
                                <input type="text" class="input-field" name="name" value="<?php echo e($subject->name); ?>">
                            </label>
                            <label for="field2"><span class="required">Test nechta chiqsin <span class="required ">*</span></span>
                                <input type="text" class="input-field" name="count" value="<?php echo e($subject->count); ?>">
                            </label>
                            <label for="field1"><span class="required">Test vaqti qancha (minut) <span class="required ">*</span></span>
                                <input type="number" class="input-field" name="time" value="<?php echo e($subject->time); ?>">
                            </label>
                            <br><br>
                            <label><button class="btn" type="submit">Saqlash</button></label>
                        </form>
                    </div>
                </div>
                <div class="form-style-2" id="form-style" style="display: none">
                    <div class="info">
                        <form action="<?php echo e(route('vacant_quiz_reg')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <label for="field1"><span class="required">Savol <span class="required ">*</span></span>
                                <textarea class="textarea-field"  name="quiz" required></textarea>
                                
                            </label>
                            <label for="field2"><span class="required">Savol rasmi <span class="required ">*</span></span>
                                <input type="file" accept="image/*" class="input-field" name="photo">
                            </label>
                            <input type="hidden" value="<?php echo e($subject->id); ?>" name="id">
                            <label for="field2"><span class="required">A javob <span class="required ">*</span></span>
                                <input type="text" class="input-field" name="a_answer">
                            </label>
                            <label for="field2"><span class="required">B javob <span class="required ">*</span></span>
                                <input type="text" class="input-field" name="b_answer">
                            </label>
                            <label for="field2"><span class="required">C javob <span class="required ">*</span></span>
                                <input type="text" class="input-field" name="c_answer">
                            </label>
                            <label for="field2"><span class="required">D javob <span class="required ">*</span></span>
                                <input type="text" class="input-field" name="d_answer">
                            </label>
                            <label for="field2"><span class="required">To'gri javob <span class="required ">*</span></span>
                                <select name="correct" class="form-control">
                                    <option>A</option>
                                    <option>B</option>
                                    <option>C</option>
                                    <option>D</option>
                                </select>
                            </label>
                            <br><br>
                            <label><button class="btn" type="submit">Kiritish</button></label>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <?php if(count($quizzes) > 0): ?>
            <div class="card shadow">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Savol</th>
                                <th>A javob</th>
                                <th>B javob</th>
                                <th>C javob</th>
                                <th>D javob</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($id+1); ?></td>
                                    <td><?php echo e($item->quiz); ?></td>
                                    <?php $__currentLoopData = $answers[$id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($answer->correct == 1): ?>
                                            <td class="text-danger"><b><?php echo e($answer->answer); ?></b></td>
                                        <?php else: ?>
                                            <td><?php echo e($answer->answer); ?></td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <td style="text-align: center; vertical-align: center"><a class="btn" href="<?php echo e(route('edit_vc_quiz', ['id' => $item->id])); ?>"><i class="fa fa-edit"></i></a></td>
                                    <td style="text-align: center; vertical-align: top">
                                        <form action="<?php echo e(route('delete_vc_quiz')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="quiz_id" value="<?php echo e($item->id); ?>">
                                            <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">
                                            <button type="submit" class="btn" style="background-color: red"><i class="fa fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <h3>Savollar mavjud emas!</h3>
        <?php endif; ?>
    </section>
    <form action="<?php echo e(route('vacant_delete_subject')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="delete_id" value="<?php echo e($subject->id); ?>">
        <input type="submit" style="display: none" id="submit-btn">
    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script type="application/javascript">
        function formOpen(){
            document.getElementById('form-style').style.display = 'block';
        }

        function openEdit(){
            document.getElementById('form-edit').style.display = 'block';
        }

        function trash(){

            if (confirm("Fan bilan qo'shilib barcha savollari ham o'chiriladi") === true) {
                document.getElementById('submit-btn').click();
            }
        }

    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\darmon\resources\views/admin/vacant_sb_details.blade.php ENDPATH**/ ?>