<?php $__env->startSection('section'); ?>
    <div class="dash-content">
        <div class="overview">
            <div class="title">
                <i class="fas fa-notes-medical"></i>
                <span class="text">Imtihon</span>
            </div>
            <form action="<?php echo e(route('vacant_test_check')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="vacant_id" value="<?php echo e($vacant->id); ?>">
                <input type="hidden" name="vacant_fullname" value="<?php echo e($vacant->fullname); ?>">
                <h1 style="text-align: center; margin-top: 1rem; color: blue"><?php echo e($subjects[0]->name); ?></h1>
                <?php $__currentLoopData = $first; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($quiz->photo != "no_photo"): ?>
                        <div class="big_test">
                            <section class="test">
                                <div class="test_questions">
                                    <div>
                                        <h2 class="test_request"><b><?php echo e($id+1); ?>. </b> <?php echo e($quiz->quiz); ?></h2>
                                        <?php $__currentLoopData = $first_answer[$id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label>
                                                <input type="radio" name="answer<?php echo e($id+1); ?>" value="<?php echo e($item->id); ?>">
                                                <span><?php echo e($item->answer); ?></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="test_image">
                                    <img src="../quiz_images/<?php echo e($quiz->photo); ?>" alt="" class="test_img">
                                </div>
                            </section>
                        </div>
                    <?php else: ?>
                        <div class="small_tests">
                            <section class="small_test">
                                <div>
                                    <h2 class="test_title"><?php echo e($id+1); ?>. </b> <?php echo e($quiz->quiz); ?></h2>
                                    <?php $__currentLoopData = $first_answer[$id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label>
                                            <input type="radio" name="answer<?php echo e($id+1); ?>" value="<?php echo e($item->id); ?>">
                                            <span><?php echo e($item->answer); ?></span>
                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </section>
                        </div>
                    <?php endif; ?>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <h1 style="text-align: center; margin-top: 1rem; color: blue"><?php echo e($subjects[1]->name); ?></h1>
                    <?php $__currentLoopData = $second; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($quiz->photo != "no_photo"): ?>
                            <div class="big_test">
                                <section class="test">
                                    <div class="test_questions">
                                        <div>
                                            <h2 class="test_request"><b><?php echo e($id+11); ?>. </b> <?php echo e($quiz->quiz); ?></h2>
                                            <?php $__currentLoopData = $first_answer[$id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label>
                                                    <input type="radio" name="answer<?php echo e($id+11); ?>" value="<?php echo e($item->id); ?>">
                                                    <span><?php echo e($item->answer); ?></span>
                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <div class="test_image">
                                        <img src="../quiz_images/<?php echo e($quiz->photo); ?>" alt="" class="test_img">
                                    </div>
                                </section>
                            </div>
                        <?php else: ?>
                            <div class="small_tests">
                                <section class="small_test">
                                    <div>
                                        <h2 class="test_title"><?php echo e($id+11); ?>. </b> <?php echo e($quiz->quiz); ?></h2>
                                        <?php $__currentLoopData = $first_answer[$id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label>
                                                <input type="radio" name="answer<?php echo e($id+11); ?>" value="<?php echo e($item->id); ?>">
                                                <span><?php echo e($item->answer); ?></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </section>
                            </div>
                        <?php endif; ?>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <h1 style="text-align: center; margin-top: 1rem; color: blue"><?php echo e($subjects[2]->name); ?></h1>
                    <?php $__currentLoopData = $third; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($quiz->photo != "no_photo"): ?>
                            <div class="big_test">
                                <section class="test">
                                    <div class="test_questions">
                                        <div>
                                            <h2 class="test_request"><b><?php echo e($id+21); ?>. </b> <?php echo e($quiz->quiz); ?></h2>
                                            <?php $__currentLoopData = $first_answer[$id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label>
                                                    <input type="radio" name="answer<?php echo e($id+21); ?>" value="<?php echo e($item->id); ?>">
                                                    <span><?php echo e($item->answer); ?></span>
                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <div class="test_image">
                                        <img src="../quiz_images/<?php echo e($quiz->photo); ?>" alt="" class="test_img">
                                    </div>
                                </section>
                            </div>
                        <?php else: ?>
                            <div class="small_tests">
                                <section class="small_test">
                                    <div>
                                        <h2 class="test_title"><?php echo e($id+21); ?>. </b> <?php echo e($quiz->quiz); ?></h2>
                                        <?php $__currentLoopData = $first_answer[$id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label>
                                                <input type="radio" name="answer<?php echo e($id+21); ?>" value="<?php echo e($item->id); ?>">
                                                <span><?php echo e($item->answer); ?></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </section>
                            </div>
                        <?php endif; ?>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <h1 style="text-align: center; margin-top: 1rem; color: blue"><?php echo e($subjects[3]->name); ?></h1>

                    <?php $__currentLoopData = $four; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($quiz->photo != "no_photo"): ?>
                            <div class="big_test">
                                <section class="test">
                                    <div class="test_questions">
                                        <div>
                                            <h2 class="test_request"><b><?php echo e($id+31); ?>. </b> <?php echo e($quiz->quiz); ?></h2>
                                            <?php $__currentLoopData = $first_answer[$id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label>
                                                    <input type="radio" name="answer<?php echo e($id+31); ?>" value="<?php echo e($item->id); ?>">
                                                    <span><?php echo e($item->answer); ?></span>
                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <div class="test_image">
                                        <img src="../quiz_images/<?php echo e($quiz->photo); ?>" alt="" class="test_img">
                                    </div>
                                </section>
                            </div>
                        <?php else: ?>
                            <div class="small_tests">
                                <section class="small_test">
                                    <div>
                                        <h2 class="test_title"><?php echo e($id+31); ?>. </b> <?php echo e($quiz->quiz); ?></h2>
                                        <?php $__currentLoopData = $first_answer[$id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label>
                                                <input type="radio" name="answer<?php echo e($id+31); ?>" value="<?php echo e($item->id); ?>">
                                                <span><?php echo e($item->answer); ?></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </section>
                            </div>
                        <?php endif; ?>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <input type="submit" id="submit" style="display: none">
            </form>
            <div class="connections">
                <div class="connection offline">
                    <i class="material-icons wifi-off">wifi_off</i>
                    <p>siz hozir oflaynsiz</p>
                    <i class="material-icons close">close</i>
                </div>
                <div class="connection online">
                    <i class="material-icons wifi">wifi</i>
                    <p>Internetga ulanishingiz tiklandi</p>
                    <i class="material-icons close">close</i>
                </div>
            </div>
        </div>
    </div>

</section>























<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        function formatTime(seconds) {
            var m = Math.floor(seconds / 60) % 60,
                s = seconds % 60;
            if (m < 10) m = "0" + m;
            if (s < 10) s = "0" + s;
            return m + ":" + s;
        }

        var count = 2400;
        var counter = setInterval(timer, 1000);

        function timer() {
            count--;
            if (count < 0){
                document.getElementById('submit').click();
            }
            document.getElementById('timer').innerHTML = formatTime(count);
        }

        function complate(){
            document.getElementById('submit').click();
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('vacant.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\darmon\resources\views/vacant/test.blade.php ENDPATH**/ ?>