<?php $__env->startSection('section'); ?>
    <div class="dash-content">
        <div class="overview">
            <div class="title">
                <i class="fal fa-chart-bar"></i>
                <span class="text">Natijalar</span>
            </div>
            <hr>
            <section class="big_chart">
                <div class="chart_circul">
                    <h3 class="circul_title"><?php echo e($subject_name); ?> fani bo'yicha natija</h3>
                    <div class="contynr">
                        <div class="progress-circular">
                            <style>
                                .progress-circular {
                                    background: conic-gradient(#469aff <?php echo e($prosent*3.6); ?>deg, #FFF 0deg);
                                }
                            </style>
                            <span class="span_value"><?php echo e($prosent); ?>%</span>
                        </div>
                    </div>
                </div>


















            </section>
            <script type="text/javascript">
                $(function(){
                    $('.bars li .bar').each(function(key, bar){
                        var percentage = $(this).data('percentage');
                        $(this).animate({
                            'height' : percentage + '%'
                        },1000);
                    });
                });
            </script>

        </div>
    </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>



<?php $__env->stopPush(); ?>

<?php echo $__env->make('nurse.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\darmon\resources\views/nurse/result.blade.php ENDPATH**/ ?>