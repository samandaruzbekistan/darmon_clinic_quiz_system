<?php $__env->startSection('section'); ?>

        <div class="dash-content">
            <div class="overview">
                <div class="title">
                    <i class="fas fa-users-cog"></i>
                    <span class="text" id="glavni">Vacant imtihon natijalari</span>
                </div>
                <a href="<?php echo e(route('exportExcel',['id' => 1])); ?>"><button class="btn" ><i class="fas fa-lock"></i> Admin login parol yangilash</button></a>
                <a href="<?php echo e(route('delete_data',['id' => 1])); ?>"><button class="btn"><i class="fas fa-users-cog"></i> Hamshira login parol yangilash</button></a>
                <br>
                <br>
            </div>
        </div>

</section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\darmon\resources\views/admin/settings.blade.php ENDPATH**/ ?>