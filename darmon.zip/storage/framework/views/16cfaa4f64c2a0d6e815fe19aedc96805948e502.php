<?php $__env->startSection('section'); ?>

    <div class="dash-content">
        <div class="overview">
            <div class="title">
                <i class="fas fa-notes-medical"></i>
                <span class="text" id="glavni">Imtihon bo'limi</span>
            </div>
            <div class="fan_cards" id="fan-cards">
                <div class="fan_card">
                    
                    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
                    <lottie-player src="https://assets10.lottiefiles.com/private_files/lf30_46kycmnm.json" background="transparent" speed="1" style="width: 300px; height: 300px;" loop="" autoplay=""></lottie-player>
                    <h2 class="fan_title">Imtihon</h2>
                    <a href="<?php echo e(route('start_vacant', ['id' => session('vacant_id')])); ?>"><button type="submit" class="fan_btn">Boshlash</button></a>
                </div>
            </div>
        </div>
    </div>

    </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('vacant.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\darmon\resources\views/vacant/home.blade.php ENDPATH**/ ?>